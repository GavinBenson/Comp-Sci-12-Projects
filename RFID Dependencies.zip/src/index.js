import React from "react";
import ReactDOM from "react-dom";

import "./styles.css";
import SearchForm from "./SearchForm";

class App extends React.Component {
  constructor() {
    super();
    this.state = {
      searchTerm: "",
      jokes: [],
      isFetchingJoke: false
    };

    this.onSearchChange = this.onSearchChange.bind(this);
    this.searchJokes = this.searchJokes.bind(this);
  }

  //componentDidMount() {
  //this.searchJokes();
  //}

  searchJokes() {
    this.setState({ isFetchingJoke: true });
    fetch(`https://icanhazdadjoke.com/search?term=${this.state.searchTerm}`, {
      method: "GET",
      headers: {
        Accept: "application/json"
      }
    })
      .then(response => response.json())
      .then(json => {
        const jokes = json.results;
        console.log("jokes", jokes);
        this.setState({
          jokes,
          isFetchingJoke: false
        });
      });
  } //event => console.log(event.target.value)

  onSearchChange(value) {
    this.setState({ searchTerm: value });
  }

  onSearchSubmit(event) {
    event.preventDefault(); //stops reloading of the page
    //console.log("form submit");
    this.searchJokes();
  }

  renderJokes() {
    return (
      <ul>
        {this.state.jokes.map(item => (
          <li key={item.id}>{item.joke}</li>
        ))}
      </ul>
    );
  }

  render() {
    return (
      <div>
        <SearchForm
          onForceSubmit={this.onSearchSubmit}
          onSearchValueChange={this.onSearchChange}
          isSearching={this.state.isFetchingJoke}
          onSingleSearchClick={() => this.searchJokes(1)}
        />

        {this.state.isFetchingJoke
          ? "searching for jokes..."
          : this.renderJokes()}
        <p />
        <p>search term: {this.state.searchTerm}</p>
      </div>
    );
  }
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App version="1.0" />, rootElement);
