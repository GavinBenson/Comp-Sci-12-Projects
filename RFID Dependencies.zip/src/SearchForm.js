import React from "react";

const SearchForm = props => {
  const onSubmit = event => {
    event.preventDefault();
    props.onFormSubmit();
  };
  return (
    <form onsubmit={props.onFormSubmit}>
      <input
        type="test"
        placeholder="Enter search term..."
        onChange={event => props.onSearchValueChange(event.target.value)}
      />
      <button disabled={props.isSearching}>Search</button>

      <button onClick={props.onSingleSearchClick} disabled={props.isSearching}>
        I'm feeling funny
      </button>
    </form>
  );
};

export default SearchForm;
